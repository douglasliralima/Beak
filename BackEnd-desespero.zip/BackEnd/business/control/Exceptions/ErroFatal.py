class ErroFatal(Exception):
    
        
    def __str__(self):
        return "Erro não previsto encontrado, favor entrar em contato com os administratores da API"